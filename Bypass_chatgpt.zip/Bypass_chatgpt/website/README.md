# ChatGPT-Bypass
website that allows you to bypass content filtering in ChatGPT through the OpenAI autocompletion API for DaVinci-003.

# How to use 

1) go to https://platform.openai.com/account/api-keys
2) generate an api key
3) paste the API key when the website asks for it and press 'OK'

![Screenshot from 2023-02-28 23-12-44](https://user-images.githubusercontent.com/106079917/221997315-e19b247f-009e-479b-9d4c-fd658de040c5.png)

# Example

![Screenshot from 2023-02-28 23-35-13](https://user-images.githubusercontent.com/106079917/221997335-8f28d874-49db-4fb4-a290-83a8ea81ee2c.png)

# Limitations

  - This model has a maximum context length of 4097 tokens. If you don't see any output, it means you have exceeded the limit. Both the question and answer are included in the 4097 tokens.
  - It can't remember the previous asked question

# credits
Based on the things discovered by -> https://github.com/GrimOutlaw/ChatGPT-Bypass

# ChatGPT-Bypass
Powershell gui script that allows you to bypass content filtering in ChatGPT through the OpenAI autocompletion API for DaVinci-003.

# Download 
https://github.com/daboynb/ChatGPT-Bypass-gui/releases/download/release/gui.exe

# How to use 

1) go to https://platform.openai.com/account/api-keys
2) generate an api key
3) paste the API key when the program asks for it and press 'OK'

![Screenshot from 2023-02-27 22-24-50](https://user-images.githubusercontent.com/106079917/221688997-83484908-06d4-472e-a594-2d54c63ea0ee.png)

# Example

![Screenshot from 2023-02-27 11-45-19](https://user-images.githubusercontent.com/106079917/221613984-5a20637b-f46f-4b12-99b9-17cf7e0b5d99.png)

# Limitations

  - This model has a maximum context length of 4097 tokens. If you don't see any output, it means you have exceeded the limit. Both the question and answer are included in the 4097 tokens.
  - It can't remember the previous asked question

# credits
Based on the things discovered by -> https://github.com/GrimOutlaw/ChatGPT-Bypass
